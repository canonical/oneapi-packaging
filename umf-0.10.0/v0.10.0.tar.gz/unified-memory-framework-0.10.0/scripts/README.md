The documentation HTML files are generated using the following dependencies:
 * [Python](https://www.python.org/downloads/) at least v3.8
 * [Doxygen](http://www.doxygen.nl/) at least v1.9.1

 To generate files run the `generate_docs.py` script from the `scripts` directory. Files will be generated to the `docs/html` directory relative to the main directory of this repository.
