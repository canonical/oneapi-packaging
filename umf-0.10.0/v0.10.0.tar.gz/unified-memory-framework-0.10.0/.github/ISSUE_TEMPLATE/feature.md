---
name: Feature
about: Request a feature/enhancement
labels: "enhancement"
---

<!-- fill the title of your feature/enhancement -->

## Rationale

<!-- fill this out -->

## Description

<!-- fill this out -->

## API Changes

<!-- fill this out, if needed -->

## Implementation details

<!-- fill this out if possible -->

## Meta

<!-- fill this out -->
